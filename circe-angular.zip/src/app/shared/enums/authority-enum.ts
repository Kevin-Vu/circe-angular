export enum AuthorityEnum {
    AMINISTRATOR = 'ADMINISTRATROR',
    MANAGER = 'MANAGER',
    USER = 'USER'
}
