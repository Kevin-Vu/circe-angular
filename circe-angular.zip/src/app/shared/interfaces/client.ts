export interface Client {
    id: number;
    firstname: string;
    lastname: string;
    clientCode: string;
    email: string;
    authority: string;
    company: string;
}
