export const environment = {
  production: true,
  BACKEND_URL: 'https://circe.live',
  JWT_TIME_EXPIRATION: 86400000
};
